import React, { useEffect, useState, useCallback } from "react";
import { PolicyAdderWizard, UPDATED_STEPS } from "./PolicyAdderWizard";
import { PolicyAdderHeader } from "./PolicyAdderHeader";

import { 
  usePolicyTypes, 
  useProducts, 
  useCoverages,
  useVehicleMakes,
  useVehicleModels,
  useVehicleCategories,
  useVehicleYears
} from "./PolicyAdderHooks";

const API_BASE = "/api";
const IN_TOKEN_KEY = "in-token";

export type RiskFactor = {
  id: string;
  name?: string;
};

export type CoverageOption = {
  id: string;
  name?: string;
  riskFactors?: RiskFactor[];
};

export type Product = {
  id: string;
  name?: string;
};

export type PolicyType = {
  id: string;
  name?: string;
};

export type SelectedCoverageState = {
  included: boolean;
  riskFactorIds: string[];
};

export type AssetType = {
  id: string;
  name?: string;
};

export const addOneYear = (dateStr: string): string => {
  if (!dateStr) return "";
  const d = new Date(dateStr + "T00:00:00");
  d.setFullYear(d.getFullYear() + 1);
  return d.toISOString().slice(0, 10);
};

// Helper function to fetch asset types
async function fetchAssetTypes(): Promise<AssetType[]> {
  try {
    const token = localStorage.getItem(IN_TOKEN_KEY);
    const res = await fetch(`${API_BASE}/asset/types`, {
      headers: {
        "Content-Type": "application/json",
        ...(token ? { Authorization: `Bearer ${token}` } : {}),
      },
    });
    
    if (!res.ok) throw new Error(`Failed to fetch asset types: ${res.status}`);
    
    const data = await res.json();
    return Array.isArray(data) ? data : [];
  } catch (error) {
    console.error("Error fetching asset types:", error);
    return [];
  }
}

export default function PolicyAdder() {
  const [currentStep, setCurrentStep] = useState(1);
  const [completedSteps, setCompletedSteps] = useState<number[]>([]);

  // Policy selection states
  const [selectedPolicyTypeId, setSelectedPolicyTypeId] = useState("");
  const [selectedProductId, setSelectedProductId] = useState("");
  const [selectedCoverages, setSelectedCoverages] = useState<Record<string, SelectedCoverageState>>({});

  // Vehicle states
  const [selectedMake, setSelectedMake] = useState<string>("");
  const [selectedModel, setSelectedModel] = useState<string>("");
  const [selectedCategory, setSelectedCategory] = useState<string>("");
  const [selectedYear, setSelectedYear] = useState<string>("");

  // Asset types state
  const [assetTypes, setAssetTypes] = useState<AssetType[]>([]);
  const [assetTypeId, setAssetTypeId] = useState<string>("");

  // Form data states
  const [policyHolder, setPolicyHolder] = useState({
    username: "",
    password: "",
    email: ""
  });

  const [policyDetails, setPolicyDetails] = useState({
    description: "My auto insurance policy",
    policyEffectiveDate: new Date().toISOString().split('T')[0],
    policyDuration: 12,
  });

  const [vehicleDetails, setVehicleDetails] = useState({
    name: "",
    value: "",
    vin: "",
    make: "",
    model: "",
    year: "",
    category: "",
  });

  const [error, setError] = useState("");
  const [success, setSuccess] = useState("");
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [loadingAssetTypes, setLoadingAssetTypes] = useState(false);

  // Hooks with their loading states
  const { policyTypes, loadingTypes: loadingPolicyTypes, fetchPolicyTypes } = usePolicyTypes(selectedPolicyTypeId, setSelectedPolicyTypeId);
  const { products, loadingProducts, fetchProducts } = useProducts(selectedPolicyTypeId, setSelectedProductId);
  const { coverageOptions, loadingCoverages, fetchCoverages } = useCoverages(selectedProductId);
  
  // Vehicle hooks
  const { makes, loading: loadingMakes, fetchMakes } = useVehicleMakes();
  const { models, loading: loadingModels, fetchModels } = useVehicleModels(selectedMake);
  const { categories, loading: loadingCategories, fetchCategories } = useVehicleCategories(selectedMake, selectedModel);
  const { years, loading: loadingYears, fetchYears } = useVehicleYears(selectedMake, selectedModel);

  // Fetch asset types and initialize data
  useEffect(() => {
    const initializeData = async () => {
      setLoadingAssetTypes(true);
      
      // Fetch asset types first
      const fetchedAssetTypes = await fetchAssetTypes();
      setAssetTypes(fetchedAssetTypes);
      
      // Find the vehicle asset type
      const vehicleAssetType = fetchedAssetTypes.find(asset => 
        asset.name?.toUpperCase() === "MOTOR" || 
        asset.name?.toLowerCase().includes("vehicle") ||
        asset.name?.toLowerCase().includes("auto")
      );
      
      if (vehicleAssetType) {
        setAssetTypeId(vehicleAssetType.id);
        console.log('✅ Found vehicle asset type:', vehicleAssetType.name, vehicleAssetType.id);
      } else if (fetchedAssetTypes.length > 0) {
        // Fallback to first asset type
        setAssetTypeId(fetchedAssetTypes[0].id);
        console.log('⚠️ Using fallback asset type:', fetchedAssetTypes[0].name, fetchedAssetTypes[0].id);
      }
      
      // Fetch other initial data
      await fetchPolicyTypes();
      await fetchMakes();
      
      setLoadingAssetTypes(false);
    };

    initializeData();
    
    // Set default policy effective date to today
    const today = new Date().toISOString().split('T')[0];
    setPolicyDetails(prev => ({
      ...prev,
      policyEffectiveDate: today
    }));
  }, [fetchPolicyTypes, fetchMakes]);

  // Fetch products when policy type is selected
  useEffect(() => {
    if (selectedPolicyTypeId) {
      fetchProducts();
    } else {
      setSelectedProductId("");
    }
  }, [selectedPolicyTypeId, fetchProducts]);

  // Fetch coverages when product is selected
  useEffect(() => {
    if (selectedProductId) {
      fetchCoverages();
    } else {
      setSelectedCoverages({});
    }
  }, [selectedProductId, fetchCoverages]);

  // Fetch dependent vehicle data
  useEffect(() => {
    if (selectedMake) {
      console.log('🚗 Fetching models for make:', selectedMake);
      fetchModels();
    }
  }, [selectedMake, fetchModels]);

  useEffect(() => {
    if (selectedMake && selectedModel) {
      console.log('🚗 Fetching categories for:', selectedMake, selectedModel);
      fetchCategories();
    }
  }, [selectedMake, selectedModel, fetchCategories]);

  useEffect(() => {
    if (selectedMake && selectedModel) {
      console.log('🚗 Fetching years for:', selectedMake, selectedModel);
      fetchYears();
    }
  }, [selectedMake, selectedModel, fetchYears]);

  // Step validation
  const validateStep = useCallback((step: number) => {
    switch(step) {
      case 1: // Policy & Asset step
        if (!selectedPolicyTypeId) {
          setError("Please select a policy type");
          return false;
        }
        if (!selectedProductId) {
          setError("Please select a product");
          return false;
        }
        if (!assetTypeId) {
          setError("Please select an asset type");
          return false;
        }
        if (!selectedMake) {
          setError("Please select a vehicle make");
          return false;
        }
        if (!selectedModel) {
          setError("Please select a vehicle model");
          return false;
        }
        return true;
        
      case 2: // Personal & Policy Details step
        if (!policyHolder.username.trim()) {
          setError("Please enter a username");
          return false;
        }
        if (!policyHolder.email.trim()) {
          setError("Please enter an email address");
          return false;
        }
        // Basic email validation
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        if (!emailRegex.test(policyHolder.email)) {
          setError("Please enter a valid email address");
          return false;
        }
        if (!policyHolder.password.trim()) {
          setError("Please enter a password");
          return false;
        }
        if (!policyDetails.policyEffectiveDate) {
          setError("Please select a policy start date");
          return false;
        }
        if (!policyDetails.policyDuration || policyDetails.policyDuration < 1 || policyDetails.policyDuration > 120) {
          setError("Please enter a valid policy duration (1-120 months)");
          return false;
        }
        return true;
        
      default:
        return true;
    }
  }, [
    selectedPolicyTypeId, 
    selectedProductId, 
    assetTypeId,
    selectedMake, 
    selectedModel,
    policyHolder,
    policyDetails
  ]);

  const handlePolicyHolderChange = useCallback((field: string | object, value?: any) => {
    if (typeof field === "object") {
      setPolicyHolder((prev) => ({ ...prev, ...(field as any) }));
    } else {
      setPolicyHolder((prev) => ({ ...prev, [field]: value }));
    }
  }, []);

  const handleVehicleDetailsChange = useCallback((field: string | object, value?: any) => {
    if (typeof field === "object") {
      setVehicleDetails((prev) => ({ ...prev, ...(field as any) }));
    } else {
      setVehicleDetails((prev) => ({ ...prev, [field]: value }));
    }
  }, []);

  const handlePolicyDetailsChange = useCallback((field: string | object, value?: any) => {
    if (typeof field === "object") {
      setPolicyDetails((prev) => ({ ...prev, ...(field as any) }));
    } else {
      setPolicyDetails((prev) => ({ ...prev, [field]: value }));
    }
  }, []);

  const handleToggleCoverageIncluded = useCallback((coverageId: string) => {
    setSelectedCoverages((prev) => {
      const current = prev[coverageId] || { included: false, riskFactorIds: [] };
      return {
        ...prev,
        [coverageId]: {
          included: !current.included,
          riskFactorIds: !current.included ? current.riskFactorIds : [],
        },
      };
    });
  }, []);

  const handleNextStep = useCallback(() => {
    // Validate current step before proceeding
    if (!validateStep(currentStep)) {
      return;
    }
    
    setCompletedSteps((prev) => (prev.includes(currentStep) ? prev : [...prev, currentStep]));
    setCurrentStep((prev) => Math.min(prev + 1, UPDATED_STEPS.length));
    setError("");
  }, [currentStep, validateStep]);

  const handlePrevStep = useCallback(() => {
    setCurrentStep((prev) => Math.max(prev - 1, 1));
    setError("");
  }, []);

  const handleGoToStep = useCallback((step: number) => {
    // Only allow going to completed steps or current step
    if (step <= currentStep || completedSteps.includes(step)) {
      setCurrentStep(step);
      setError("");
    }
  }, [currentStep, completedSteps]);

  const handleSubmit = async () => {
    setError("");
    setSuccess("");
    setIsSubmitting(true);

    // Final validation before submission
    if (!validateStep(1) || !validateStep(2)) {
      // If validation fails, go to the first incomplete step
      if (!validateStep(1)) {
        setCurrentStep(1);
      } else if (!validateStep(2)) {
        setCurrentStep(2);
      }
      setIsSubmitting(false);
      return;
    }

    // If asset type is not found yet, fetch it
    if (!assetTypeId) {
      const fetchedAssetTypes = await fetchAssetTypes();
      const vehicleAssetType = fetchedAssetTypes.find(asset => asset.name?.toUpperCase() === "MOTOR");
      if (vehicleAssetType) {
        setAssetTypeId(vehicleAssetType.id);
      } else {
        setError("Unable to determine vehicle asset type. Please try again.");
        setIsSubmitting(false);
        return;
      }
    }

    // Build the request body according to backend expectations
    const selectedCoverageIds = Object.entries(selectedCoverages)
      .filter(([, cfg]) => cfg.included)
      .map(([coverageId]) => coverageId);

    const baseBody: any = {
      description: policyDetails.description || "Auto Insurance Policy",
      policyTypeId: selectedPolicyTypeId,
      assets: [
        {
          assetType: assetTypeId, // ✅ Dynamic asset type ID
          asset: {
            name: vehicleDetails.name || `${vehicleDetails.make} ${vehicleDetails.model}`.trim() || "Vehicle",
            value: vehicleDetails.value ? Number(vehicleDetails.value) : 25000,
            vin: vehicleDetails.vin || "",
            make: vehicleDetails.make,
            model: vehicleDetails.model,
            year: vehicleDetails.year ? Number(vehicleDetails.year) : 2022,
            category: vehicleDetails.category || ""
          },
          selectedProducts: [selectedProductId],
          selectedCoverageOptions: selectedCoverageIds,
        },
      ],
      policyDetails: {
        policyEffectiveDate: policyDetails.policyEffectiveDate,
        policyDuration: policyDetails.policyDuration,
      },
      policyHolder: {
        username: policyHolder.username,
        password: policyHolder.password,
        email: policyHolder.email
      }
    };

    console.log('Submitting policy with payload:', JSON.stringify(baseBody, null, 2));
    console.log('Using asset type ID:', assetTypeId);

    try {
      const token = localStorage.getItem(IN_TOKEN_KEY);
      const res = await fetch(`${API_BASE}/policies/n/i`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          ...(token ? { Authorization: `Bearer ${token}` } : {}),
        },
        body: JSON.stringify(baseBody),
      });

      if (res.ok) {
        const result = await res.json();
        setSuccess(`Thank you, ${policyHolder.username}! Your policy request has been submitted successfully. Your policy ID is ${result.policyId || 'pending'}.`);
        setCompletedSteps((prev) => [...prev, 3]);
        
        // Reset form after successful submission
        setTimeout(() => {
          setPolicyHolder({ username: "", password: "", email: "" });
          setPolicyDetails({
            description: "My auto insurance policy",
            policyEffectiveDate: new Date().toISOString().split('T')[0],
            policyDuration: 12,
          });
          setVehicleDetails({
            name: "",
            value: "",
            vin: "",
            make: "",
            model: "",
            year: "",
            category: "",
          });
          setSelectedPolicyTypeId("");
          setSelectedProductId("");
          setSelectedCoverages({});
          setSelectedMake("");
          setSelectedModel("");
          setSelectedCategory("");
          setSelectedYear("");
          setAssetTypeId("");
          setCurrentStep(1);
          setCompletedSteps([]);
        }, 3000);
      } else {
        const errorText = await res.text();
        console.error('❌ Submission error:', errorText);
        setError(`Unable to submit your request: ${errorText}`);
      }
    } catch (err: any) {
      console.error('❌ Network error:', err);
      setError(`Unable to submit your request: ${err.message}`);
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-slate-50 to-white py-8 px-4 sm:px-6 lg:px-8">
      <div className="max-w-6xl mx-auto">
        <PolicyAdderHeader />
        
        {error && (
          <div className="mb-6 rounded-xl border border-red-200 bg-red-50 p-4 animate-fadeIn">
            <div className="flex items-center gap-3">
              <div className="flex-shrink-0">
                <div className="w-5 h-5 rounded-full bg-red-100 flex items-center justify-center">
                  <span className="text-red-600 text-sm font-bold">!</span>
                </div>
              </div>
              <p className="text-sm font-medium text-red-800">{error}</p>
            </div>
          </div>
        )}

        {success && (
          <div className="mb-6 rounded-xl border border-emerald-200 bg-emerald-50 p-4 animate-fadeIn">
            <div className="flex items-center gap-3">
              <div className="flex-shrink-0">
                <div className="w-5 h-5 rounded-full bg-emerald-100 flex items-center justify-center">
                  <span className="text-emerald-600 text-sm font-bold">✓</span>
                </div>
              </div>
              <p className="text-sm font-medium text-emerald-800">{success}</p>
            </div>
          </div>
        )}

        <PolicyAdderWizard
          currentStep={currentStep}
          completedSteps={completedSteps}
          goToStep={handleGoToStep}
          
          // Asset type data
          assetTypes={assetTypes}
          assetTypeId={assetTypeId}
          setAssetTypeId={setAssetTypeId}
          
          // Policy type data
          policyTypes={policyTypes}
          selectedPolicyTypeId={selectedPolicyTypeId}
          setSelectedPolicyTypeId={setSelectedPolicyTypeId}
          
          // Product data
          products={products}
          selectedProductId={selectedProductId}
          setSelectedProductId={setSelectedProductId}
          
          // Coverage data
          coverageOptions={coverageOptions}
          selectedCoverages={selectedCoverages}
          toggleCoverageIncluded={handleToggleCoverageIncluded}
          
          // Loading states
          loadingProducts={loadingProducts}
          loadingCoverages={loadingCoverages}
          loadingMakes={loadingMakes}
          loadingModels={loadingModels}
          loadingCategories={loadingCategories}
          loadingYears={loadingYears}
          
          // Vehicle data
          makes={makes}
          models={models}
          categories={categories}
          years={years}
          selectedMake={selectedMake}
          setSelectedMake={setSelectedMake}
          selectedModel={selectedModel}
          setSelectedModel={setSelectedModel}
          selectedCategory={selectedCategory}
          setSelectedCategory={setSelectedCategory}
          selectedYear={selectedYear}
          setSelectedYear={setSelectedYear}
          
          // Form data
          policyHolder={policyHolder}
          setPolicyHolder={handlePolicyHolderChange}
          policyDetails={policyDetails}
          setPolicyDetails={handlePolicyDetailsChange}
          vehicleDetails={vehicleDetails}
          setVehicleDetails={handleVehicleDetailsChange}
          
          // Navigation
          prevStep={handlePrevStep}
          nextStep={handleNextStep}
          handleSubmit={handleSubmit}
          
          // Submission state
          isSubmitting={isSubmitting}
        />

        {/* Loading indicators for initial data */}
        {(loadingPolicyTypes || loadingMakes || loadingAssetTypes) && (
          <div className="mt-6 text-center">
            <div className="inline-flex items-center gap-2 text-sm text-slate-500">
              <div className="w-4 h-4 border-2 border-slate-300 border-t-slate-600 rounded-full animate-spin"></div>
              <span>Loading initial data...</span>
            </div>
          </div>
        )}

        {/* Footer */}
        <div className="mt-12 pt-8 border-t border-slate-200">
          <div className="text-center">
            <p className="text-sm text-slate-600">
              Need assistance? Contact our support team at{" "}
              <a href="mailto:support@insure.com" className="text-blue-600 hover:text-blue-800 font-medium">
                support@insure.com
              </a>
            </p>
            <p className="mt-2 text-xs text-slate-500">
              By submitting your application, you agree to our{" "}
              <a href="#" className="text-blue-600 hover:text-blue-800">Terms of Service</a>{" "}
              and{" "}
              <a href="#" className="text-blue-600 hover:text-blue-800">Privacy Policy</a>
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}