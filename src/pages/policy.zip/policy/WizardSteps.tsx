// src/pages/policy/WizardSteps.tsx
import React from "react";
import { 
  Shield, 
  User, 
  Car, 
  CheckCircle, 
  Calendar,
  ChevronRight,
  Info
} from "lucide-react";
import {
  PolicyType,
  Product,
  CoverageOption,
  SelectedCoverageState,
} from "./PolicyAdder";

// Common props interface
interface CommonStepProps {
  policyHolder: any;
  setPolicyHolder: (field: string | object, value?: any) => void;
  policyDetails: any;
  setPolicyDetails: (field: string | object, value?: any) => void;
  vehicleDetails: any;
  setVehicleDetails: (field: string | object, value?: any) => void;
  handleKeyDown: (e: React.KeyboardEvent) => void;
}

// Step 1: Policy & Asset Selection (Combined)
interface Step1Props extends CommonStepProps {
  policyTypes: PolicyType[];
  products: Product[];
  selectedPolicyTypeId: string;
  selectedProductId: string;
  setSelectedPolicyTypeId: (id: string) => void;
  setSelectedProductId: (id: string) => void;
  loadingProducts: boolean;
  coverageOptions: CoverageOption[];
  selectedCoverages: Record<string, SelectedCoverageState>;
  toggleCoverageIncluded: (coverageId: string) => void;
  makes: Array<{make?: string, name?: string, id?: string}>;
  models: Array<{model?: string, name?: string, id?: string}>;
  categories: Array<{category?: string, name?: string, id?: string}>;
  years: Array<{year?: number, name?: string, id?: string}>;
  selectedMake: string;
  setSelectedMake: (value: string) => void;
  selectedModel: string;
  setSelectedModel: (value: string) => void;
  selectedCategory: string;
  setSelectedCategory: (value: string) => void;
  selectedYear: string;
  setSelectedYear: (value: string) => void;
  loadingMakes: boolean;
  loadingModels: boolean;
  loadingCategories: boolean;
  loadingYears: boolean;
}

export const Step1PolicyAsset: React.FC<Step1Props> = ({
  policyTypes,
  products,
  selectedPolicyTypeId,
  selectedProductId,
  setSelectedPolicyTypeId,
  setSelectedProductId,
  loadingProducts,
  coverageOptions,
  selectedCoverages,
  toggleCoverageIncluded,
  makes,
  models,
  categories,
  years,
  selectedMake,
  setSelectedMake,
  selectedModel,
  setSelectedModel,
  selectedCategory,
  setSelectedCategory,
  selectedYear,
  setSelectedYear,
  loadingMakes,
  loadingModels,
  loadingCategories,
  loadingYears,
  vehicleDetails,
  setVehicleDetails,
  handleKeyDown,
}) => {
  const selectedType = policyTypes.find((t) => t.id === selectedPolicyTypeId);
  const selectedProduct = products.find((p) => p.id === selectedProductId);

  const handleMakeChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    const value = e.target.value;
    setSelectedMake(value);
    setSelectedModel("");
    setSelectedCategory("");
    setSelectedYear("");
    setVehicleDetails({ make: value, model: "", category: "", year: "" });
  };

  const handleModelChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    const value = e.target.value;
    setSelectedModel(value);
    setSelectedCategory("");
    setSelectedYear("");
    setVehicleDetails({ model: value, category: "", year: "" });
  };

  const handleCategoryChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    const value = e.target.value;
    setSelectedCategory(value);
    setSelectedYear("");
    setVehicleDetails({ category: value, year: "" });
  };

  const handleYearChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    const value = e.target.value;
    setSelectedYear(value);
    setVehicleDetails("year", value);
  };

  const handleVehicleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setVehicleDetails(name, value);
  };

  return (
    <div className="space-y-8">
      {/* Header */}
      <div className="text-center">
        <div className="inline-flex items-center justify-center w-12 h-12 rounded-full bg-blue-100 mb-4">
          <Shield className="w-6 h-6 text-blue-600" />
        </div>
        <h2 className="text-2xl font-bold text-gray-900">Choose Your Protection</h2>
        <p className="mt-2 text-gray-600">Select what you want to insure and how you want to protect it</p>
      </div>

      <div className="grid lg:grid-cols-2 gap-8">
        {/* Left Column - Policy & Coverage */}
        <div className="space-y-6">
          <div className="bg-white rounded-xl border border-gray-200 p-6 shadow-sm">
            <div className="flex items-center gap-3 mb-4">
              <div className="w-8 h-8 rounded-lg bg-blue-50 flex items-center justify-center">
                <Shield className="w-4 h-4 text-blue-600" />
              </div>
              <h3 className="font-semibold text-gray-900">Policy Details</h3>
            </div>

            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Insurance Type
                </label>
                <div className="grid grid-cols-2 gap-3">
                  {policyTypes.map((pt) => (
                    <button
                      key={pt.id}
                      type="button"
                      onClick={() => {
                        setSelectedPolicyTypeId(pt.id);
                        setSelectedProductId("");
                      }}
                      className={`p-3 rounded-lg border text-sm font-medium transition-all ${
                        selectedPolicyTypeId === pt.id
                          ? "border-blue-500 bg-blue-50 text-blue-700 ring-2 ring-blue-100"
                          : "border-gray-200 hover:border-gray-300 hover:bg-gray-50 text-gray-700"
                      }`}
                    >
                      {pt.name || pt.id}
                    </button>
                  ))}
                </div>
              </div>

              {selectedPolicyTypeId && (
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Select Product
                  </label>
                  <div className="grid grid-cols-2 gap-3">
                    {products.map((prod) => (
                      <button
                        key={prod.id}
                        type="button"
                        onClick={() => setSelectedProductId(prod.id)}
                        className={`p-3 rounded-lg border text-sm font-medium transition-all ${
                          selectedProductId === prod.id
                            ? "border-green-500 bg-green-50 text-green-700 ring-2 ring-green-100"
                            : "border-gray-200 hover:border-gray-300 hover:bg-gray-50 text-gray-700"
                        }`}
                        disabled={loadingProducts}
                      >
                        {prod.name || prod.id}
                      </button>
                    ))}
                  </div>
                </div>
              )}

              {selectedProduct && (
                <div className="rounded-lg bg-green-50 border border-green-200 p-4">
                  <div className="flex items-start gap-3">
                    <CheckCircle className="w-5 h-5 text-green-600 mt-0.5" />
                    <div>
                      <p className="font-medium text-green-800">Product Selected</p>
                      <p className="text-sm text-green-700 mt-1">
                        {selectedProduct.name || selectedProduct.id}
                      </p>
                    </div>
                  </div>
                </div>
              )}
            </div>
          </div>

          {/* Coverage Options */}
          {coverageOptions.length > 0 && (
            <div className="bg-white rounded-xl border border-gray-200 p-6 shadow-sm">
              <div className="flex items-center gap-3 mb-4">
                <div className="w-8 h-8 rounded-lg bg-purple-50 flex items-center justify-center">
                  <Info className="w-4 h-4 text-purple-600" />
                </div>
                <h3 className="font-semibold text-gray-900">Add Extra Protection</h3>
              </div>
              
              <p className="text-sm text-gray-600 mb-4">Select additional coverage options</p>
              
              <div className="space-y-3">
                {coverageOptions.map((cov) => {
                  const isSelected = !!selectedCoverages?.[cov.id]?.included;
                  return (
                    <button
                      key={cov.id}
                      type="button"
                      onClick={() => toggleCoverageIncluded(cov.id)}
                      className={`w-full flex items-center justify-between p-3 rounded-lg border transition-all ${
                        isSelected
                          ? "border-purple-500 bg-purple-50"
                          : "border-gray-200 hover:border-gray-300 hover:bg-gray-50 text-gray-700"
                      }`}
                    >
                      <div className="text-left">
                        <p className="font-medium text-gray-900">{cov.name || cov.id}</p>
                        <p className="text-xs text-gray-500 mt-1">Additional coverage option</p>
                      </div>
                      <div className={`w-6 h-6 rounded-full border-2 flex items-center justify-center ${
                        isSelected
                          ? "border-purple-500 bg-purple-500"
                          : "border-gray-300"
                      }`}>
                        {isSelected && (
                          <CheckCircle className="w-4 h-4 text-white" />
                        )}
                      </div>
                    </button>
                  );
                })}
              </div>
            </div>
          )}
        </div>

        {/* Right Column - Asset Details */}
        <div className="space-y-6">
          <div className="bg-white rounded-xl border border-gray-200 p-6 shadow-sm">
            <div className="flex items-center gap-3 mb-4">
              <div className="w-8 h-8 rounded-lg bg-orange-50 flex items-center justify-center">
                <Car className="w-4 h-4 text-orange-600" />
              </div>
              <h3 className="font-semibold text-gray-900">Vehicle Information</h3>
            </div>

            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Vehicle Details
                </label>
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <select
                      value={selectedMake || ""}
                      onChange={handleMakeChange}
                      className="w-full px-3 py-2.5 text-sm rounded-lg border border-gray-300 focus:border-blue-500 focus:ring-2 focus:ring-blue-200"
                      disabled={loadingMakes}
                    >
                      <option value="">Make</option>
                      {makes.map((make) => (
                        <option key={make.id || make.make} value={make.make || make.id}>
                          {make.make || make.name || make.id}
                        </option>
                      ))}
                    </select>
                  </div>
                  
                  <div>
                    <select
                      value={selectedModel || ""}
                      onChange={handleModelChange}
                      className="w-full px-3 py-2.5 text-sm rounded-lg border border-gray-300 focus:border-blue-500 focus:ring-2 focus:ring-blue-200"
                      disabled={!selectedMake || loadingModels}
                    >
                      <option value="">Model</option>
                      {models.map((model) => (
                        <option key={model.id || model.model} value={model.model || model.id}>
                          {model.model || model.name || model.id}
                        </option>
                      ))}
                    </select>
                  </div>
                </div>

              <div className="grid grid-cols-2 gap-3 mt-3">
  <div>
    <select
      value={selectedCategory || ""}
      onChange={handleCategoryChange}
      className="w-full px-3 py-2.5 text-sm rounded-lg border border-gray-300 focus:border-blue-500 focus:ring-2 focus:ring-blue-200"
      disabled={!selectedMake || !selectedModel || loadingCategories}
    >
      <option value="">Category</option>
      {categories.map((cat) => (
        <option key={cat.id || cat.category} value={cat.category || cat.id}>
          {cat.category || cat.name || cat.id}
        </option>
      ))}
    </select>
  </div>
  
  <div>
    <select
      value={selectedYear || ""}
      onChange={handleYearChange}
      className="w-full px-3 py-2.5 text-sm rounded-lg border border-gray-300 focus:border-blue-500 focus:ring-2 focus:ring-blue-200"
      disabled={!selectedMake || !selectedModel || loadingYears}
    >
      <option value="">Year</option>
      {years.map((yearItem) => (
        <option key={yearItem.id || yearItem.year} value={yearItem.year || yearItem.id}>
          {yearItem.year || yearItem.name || yearItem.id}
        </option>
      ))}
    </select>
  </div>
</div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Vehicle Name
                  </label>
                  <input
                    type="text"
                    name="name"
                    value={vehicleDetails?.name || ""}
                    onChange={handleVehicleInputChange}
                    onKeyDown={handleKeyDown}
                    className="w-full px-3 py-2.5 text-sm rounded-lg border border-gray-300 focus:border-blue-500 focus:ring-2 focus:ring-blue-200"
                    placeholder="e.g., My Honda Civic"
                  />
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Vehicle Value ($)
                  </label>
                  <input
                    type="number"
                    name="value"
                    value={vehicleDetails?.value || ""}
                    onChange={handleVehicleInputChange}
                    onKeyDown={handleKeyDown}
                    className="w-full px-3 py-2.5 text-sm rounded-lg border border-gray-300 focus:border-blue-500 focus:ring-2 focus:ring-blue-200"
                    placeholder="e.g., 25000"
                  />
                </div>
              </div>
            </div>
          </div>

          {/* Quick Summary */}
          {(selectedMake || selectedModel) && (
            <div className="bg-gray-50 rounded-xl border border-gray-200 p-4">
              <h4 className="font-medium text-gray-900 mb-2">Selected Vehicle</h4>
              <div className="space-y-2 text-sm">
                {selectedMake && (
                  <div className="flex justify-between">
                    <span className="text-gray-600">Make:</span>
                    <span className="font-medium">{selectedMake}</span>
                  </div>
                )}
                {selectedModel && (
                  <div className="flex justify-between">
                    <span className="text-gray-600">Model:</span>
                    <span className="font-medium">{selectedModel}</span>
                  </div>
                )}
                {selectedCategory && (
                  <div className="flex justify-between">
                    <span className="text-gray-600">Category:</span>
                    <span className="font-medium">{selectedCategory}</span>
                  </div>
                )}
                {selectedYear && (
                  <div className="flex justify-between">
                    <span className="text-gray-600">Year:</span>
                    <span className="font-medium">{selectedYear}</span>
                  </div>
                )}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

// Step 2: Personal & Policy Details
interface Step2Props extends CommonStepProps {
  policyTypes: PolicyType[];
  products: Product[];
  selectedPolicyTypeId: string;
  selectedProductId: string;
}

export const Step2PersonalPolicy: React.FC<Step2Props> = ({
  policyHolder,
  setPolicyHolder,
  policyDetails,
  setPolicyDetails,
  handleKeyDown,
  selectedPolicyTypeId,
  selectedProductId,
  policyTypes,
  products,
}) => {
  const selectedType = policyTypes.find((t) => t.id === selectedPolicyTypeId);
  const selectedProduct = products.find((p) => p.id === selectedProductId);

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setPolicyHolder(name, value);
  };

  const handlePolicyChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setPolicyDetails(name, value);
  };

  const getCurrentDate = () => {
    const today = new Date();
    return today.toISOString().split('T')[0];
  };

  return (
    <div className="space-y-8">
      {/* Header */}
      <div className="text-center">
        <div className="inline-flex items-center justify-center w-12 h-12 rounded-full bg-green-100 mb-4">
          <User className="w-6 h-6 text-green-600" />
        </div>
        <h2 className="text-2xl font-bold text-gray-900">Your Information</h2>
        <p className="mt-2 text-gray-600">Tell us about yourself and set up your policy</p>
      </div>

      <div className="grid lg:grid-cols-2 gap-8">
        {/* Left Column - Personal Details */}
        <div className="space-y-6">
          <div className="bg-white rounded-xl border border-gray-200 p-6 shadow-sm">
            <div className="flex items-center gap-3 mb-6">
              <div className="w-8 h-8 rounded-lg bg-green-50 flex items-center justify-center">
                <User className="w-4 h-4 text-green-600" />
              </div>
              <h3 className="font-semibold text-gray-900">Account Setup</h3>
            </div>

            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Username
                </label>
                <input
                  type="text"
                  name="username"
                  value={policyHolder?.username || ""}
                  onChange={handleInputChange}
                  onKeyDown={handleKeyDown}
                  className="w-full px-4 py-3 text-sm rounded-lg border border-gray-300 focus:border-blue-500 focus:ring-2 focus:ring-blue-200"
                  placeholder="Choose your username"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Email Address
                </label>
                <input
                  type="email"
                  name="email"
                  value={policyHolder?.email || ""}
                  onChange={handleInputChange}
                  onKeyDown={handleKeyDown}
                  className="w-full px-4 py-3 text-sm rounded-lg border border-gray-300 focus:border-blue-500 focus:ring-2 focus:ring-blue-200"
                  placeholder="your.email@example.com"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Password
                </label>
                <input
                  type="password"
                  name="password"
                  value={policyHolder?.password || ""}
                  onChange={handleInputChange}
                  onKeyDown={handleKeyDown}
                  className="w-full px-4 py-3 text-sm rounded-lg border border-gray-300 focus:border-blue-500 focus:ring-2 focus:ring-blue-200"
                  placeholder="Create a secure password"
                />
              </div>
            </div>
          </div>
        </div>

        {/* Right Column - Policy Details */}
        <div className="space-y-6">
          <div className="bg-white rounded-xl border border-gray-200 p-6 shadow-sm">
            <div className="flex items-center gap-3 mb-6">
              <div className="w-8 h-8 rounded-lg bg-blue-50 flex items-center justify-center">
                <Calendar className="w-4 h-4 text-blue-600" />
              </div>
              <h3 className="font-semibold text-gray-900">Policy Timeline</h3>
            </div>

            <div className="space-y-6">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Policy Description
                </label>
                <textarea
                  name="description"
                  value={policyDetails?.description || ""}
                  onChange={handlePolicyChange}
                  rows={3}
                  className="w-full px-4 py-3 text-sm rounded-lg border border-gray-300 focus:border-blue-500 focus:ring-2 focus:ring-blue-200"
                  placeholder="e.g., Comprehensive auto insurance for daily commute"
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Start Date
                  </label>
                  <input
                    type="date"
                    name="policyEffectiveDate"
                    value={policyDetails?.policyEffectiveDate || getCurrentDate()}
                    onChange={handlePolicyChange}
                    className="w-full px-4 py-3 text-sm rounded-lg border border-gray-300 focus:border-blue-500 focus:ring-2 focus:ring-blue-200"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Duration
                  </label>
                  <div className="relative">
                    <input
                      type="number"
                      name="policyDuration"
                      value={policyDetails?.policyDuration || "12"}
                      onChange={handlePolicyChange}
                      className="w-full px-4 py-3 text-sm rounded-lg border border-gray-300 focus:border-blue-500 focus:ring-2 focus:ring-blue-200 pr-12"
                    />
                    <div className="absolute right-3 top-1/2 -translate-y-1/2 text-sm text-gray-500">
                      months
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Policy Summary Card */}
          <div className="bg-blue-50 rounded-xl border border-blue-200 p-5">
            <h4 className="font-semibold text-blue-900 mb-3">Your Policy Summary</h4>
            <div className="space-y-3">
              {selectedType && (
                <div className="flex items-center justify-between">
                  <span className="text-sm text-blue-700">Cover Type:</span>
                  <span className="font-medium text-blue-900">{selectedType.name}</span>
                </div>
              )}
              
              {selectedProduct && (
                <div className="flex items-center justify-between">
                  <span className="text-sm text-blue-700">Product:</span>
                  <span className="font-medium text-blue-900">{selectedProduct.name}</span>
                </div>
              )}
              
              {policyDetails?.policyEffectiveDate && (
                <div className="flex items-center justify-between">
                  <span className="text-sm text-blue-700">Start Date:</span>
                  <span className="font-medium text-blue-900">
                    {new Date(policyDetails.policyEffectiveDate).toLocaleDateString()}
                  </span>
                </div>
              )}
              
              {policyDetails?.policyDuration && (
                <div className="flex items-center justify-between">
                  <span className="text-sm text-blue-700">Duration:</span>
                  <span className="font-medium text-blue-900">
                    {policyDetails.policyDuration} months
                  </span>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

// Step 3: Review & Submit
interface Step3Props {
  selectedPolicyTypeId: string;
  selectedProductId: string;
  selectedMake: string;
  selectedModel: string;
  selectedCategory: string;
  selectedYear: string;
  policyTypes: PolicyType[];
  products: Product[];
  makes: Array<{make?: string, name?: string, id?: string}>;
  models: Array<{model?: string, name?: string, id?: string}>;
  categories: Array<{category?: string, name?: string, id?: string}>;
  years: Array<{year?: number, name?: string, id?: string}>;
  selectedCoverages: Record<string, SelectedCoverageState>;
  coverageOptions: CoverageOption[];
  policyHolder: any;
  policyDetails: any;
  vehicleDetails: any;
  isSubmitting: boolean;
  onSubmit: () => void;
}

export const Step3ReviewSubmit: React.FC<Step3Props> = ({
  selectedPolicyTypeId,
  selectedProductId,
  selectedMake,
  selectedModel,
  selectedCategory,
  selectedYear,
  policyTypes,
  products,
  makes,
  models,
  categories,
  years,
  selectedCoverages,
  coverageOptions,
  policyHolder,
  policyDetails,
  vehicleDetails,
  isSubmitting,
  onSubmit,
}) => {
  const selectedType = policyTypes.find((t) => t.id === selectedPolicyTypeId);
  const selectedProduct = products.find((p) => p.id === selectedProductId);

  const includedCoverages = coverageOptions.filter(
    (cov) => !!selectedCoverages?.[cov.id]?.included
  );

  const formatDate = (dateString?: string) => {
    if (!dateString) return "Not set";
    try {
      return new Date(dateString).toLocaleDateString('en-US', {
        year: 'numeric',
        month: 'long',
        day: 'numeric'
      });
    } catch {
      return dateString;
    }
  };

  const formatCurrency = (value?: number | string) => {
    if (!value) return "—";
    const numValue = typeof value === 'string' ? parseFloat(value) : value;
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD'
    }).format(numValue);
  };

  return (
    <div className="space-y-8">
      {/* Header */}
      <div className="text-center">
        <div className="inline-flex items-center justify-center w-12 h-12 rounded-full bg-purple-100 mb-4">
          <CheckCircle className="w-6 h-6 text-purple-600" />
        </div>
        <h2 className="text-2xl font-bold text-gray-900">Review & Submit</h2>
        <p className="mt-2 text-gray-600">Review your information and complete your application</p>
      </div>

      {/* Progress Steps */}
      <div className="flex items-center justify-center">
        <div className="flex items-center">
          <div className="flex items-center">
            <div className="w-8 h-8 rounded-full bg-blue-600 text-white flex items-center justify-center text-sm font-medium">
              1
            </div>
            <div className="ml-2 text-sm font-medium text-blue-600">Policy & Asset</div>
          </div>
          
          <div className="w-12 h-0.5 bg-blue-600 mx-4"></div>
          
          <div className="flex items-center">
            <div className="w-8 h-8 rounded-full bg-blue-600 text-white flex items-center justify-center text-sm font-medium">
              2
            </div>
            <div className="ml-2 text-sm font-medium text-blue-600">Personal Info</div>
          </div>
          
          <div className="w-12 h-0.5 bg-blue-600 mx-4"></div>
          
          <div className="flex items-center">
            <div className="w-8 h-8 rounded-full bg-purple-600 text-white flex items-center justify-center text-sm font-medium">
              3
            </div>
            <div className="ml-2 text-sm font-medium text-purple-600">Review</div>
          </div>
        </div>
      </div>

      {/* Review Cards */}
      <div className="grid lg:grid-cols-3 gap-6">
        {/* Policy Card */}
        <div className="bg-white rounded-xl border border-gray-200 p-5 shadow-sm">
          <div className="flex items-center gap-3 mb-4">
            <Shield className="w-5 h-5 text-blue-600" />
            <h3 className="font-semibold text-gray-900">Policy Details</h3>
          </div>
          
          <div className="space-y-3">
            <div>
              <p className="text-xs text-gray-500">Policy Type</p>
              <p className="font-medium text-gray-900">{selectedType?.name || "Not selected"}</p>
            </div>
            
            <div>
              <p className="text-xs text-gray-500">Product</p>
              <p className="font-medium text-gray-900">{selectedProduct?.name || "Not selected"}</p>
            </div>
            
            <div>
              <p className="text-xs text-gray-500">Description</p>
              <p className="font-medium text-gray-900">{policyDetails?.description || "Not provided"}</p>
            </div>
            
            <div className="grid grid-cols-2 gap-3 pt-3 border-t">
              <div>
                <p className="text-xs text-gray-500">Start Date</p>
                <p className="font-medium text-gray-900">{formatDate(policyDetails?.policyEffectiveDate)}</p>
              </div>
              
              <div>
                <p className="text-xs text-gray-500">Duration</p>
                <p className="font-medium text-gray-900">
                  {policyDetails?.policyDuration ? `${policyDetails.policyDuration} months` : "Not set"}
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* Vehicle Card */}
        <div className="bg-white rounded-xl border border-gray-200 p-5 shadow-sm">
          <div className="flex items-center gap-3 mb-4">
            <Car className="w-5 h-5 text-orange-600" />
            <h3 className="font-semibold text-gray-900">Vehicle Details</h3>
          </div>
          
          <div className="space-y-3">
            <div className="grid grid-cols-2 gap-3">
              <div>
                <p className="text-xs text-gray-500">Make</p>
                <p className="font-medium text-gray-900">{selectedMake || "Not selected"}</p>
              </div>
              
              <div>
                <p className="text-xs text-gray-500">Model</p>
                <p className="font-medium text-gray-900">{selectedModel || "Not selected"}</p>
              </div>
            </div>
            
            <div className="grid grid-cols-2 gap-3">
              <div>
                <p className="text-xs text-gray-500">Category</p>
                <p className="font-medium text-gray-900">{selectedCategory || "Not selected"}</p>
              </div>
              
              <div>
                <p className="text-xs text-gray-500">Year</p>
                <p className="font-medium text-gray-900">{selectedYear || "Not selected"}</p>
              </div>
            </div>
            
            <div className="grid grid-cols-2 gap-3 pt-3 border-t">
              <div>
                <p className="text-xs text-gray-500">Vehicle Name</p>
                <p className="font-medium text-gray-900">{vehicleDetails?.name || "Not provided"}</p>
              </div>
              
              <div>
                <p className="text-xs text-gray-500">Value</p>
                <p className="font-medium text-gray-900">{formatCurrency(vehicleDetails?.value)}</p>
              </div>
            </div>
          </div>
        </div>

        {/* Account Card */}
        <div className="bg-white rounded-xl border border-gray-200 p-5 shadow-sm">
          <div className="flex items-center gap-3 mb-4">
            <User className="w-5 h-5 text-green-600" />
            <h3 className="font-semibold text-gray-900">Account Details</h3>
          </div>
          
          <div className="space-y-3">
            <div>
              <p className="text-xs text-gray-500">Username</p>
              <p className="font-medium text-gray-900">{policyHolder?.username || "Not set"}</p>
            </div>
            
            <div>
              <p className="text-xs text-gray-500">Email</p>
              <p className="font-medium text-gray-900">{policyHolder?.email || "Not set"}</p>
            </div>
            
            <div className="pt-3 border-t">
              <p className="text-xs text-gray-500">Password</p>
              <p className="font-medium text-gray-900">••••••••</p>
            </div>
          </div>

          {/* Coverage Summary */}
          {includedCoverages.length > 0 && (
            <div className="mt-4 pt-4 border-t">
              <h4 className="text-sm font-medium text-gray-900 mb-2">Extra Coverage</h4>
              <div className="space-y-2">
                {includedCoverages.map((cov) => (
                  <div key={cov.id} className="flex items-center gap-2">
                    <CheckCircle className="w-4 h-4 text-green-500" />
                    <span className="text-sm text-gray-700">{cov.name || cov.id}</span>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Final CTA */}
      <div className="bg-gradient-to-r from-blue-50 to-indigo-50 rounded-xl border border-blue-200 p-8 text-center">
        <CheckCircle className="w-12 h-12 text-blue-600 mx-auto mb-4" />
        
        <h3 className="text-xl font-bold text-gray-900 mb-2">
          Ready to Get Protected?
        </h3>
        
        <p className="text-gray-600 mb-6 max-w-2xl mx-auto">
          Your insurance application is complete and ready to submit. Once submitted, 
          you'll receive a confirmation email and your policy documents.
        </p>

        <div className="flex flex-col sm:flex-row gap-4 justify-center">
          <button
            type="button"
            onClick={onSubmit}
            disabled={isSubmitting}
            className="inline-flex items-center justify-center px-8 py-3 text-base font-medium text-white bg-blue-600 rounded-lg hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
          >
            {isSubmitting ? (
              <>
                <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin mr-2"></div>
                Submitting...
              </>
            ) : (
              <>
                Submit Application
                <ChevronRight className="ml-2 w-5 h-5" />
              </>
            )}
          </button>
          
          <button
            type="button"
            onClick={() => window.print()}
            className="inline-flex items-center justify-center px-8 py-3 text-base font-medium text-gray-700 bg-white border border-gray-300 rounded-lg hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-gray-500 transition-colors"
          >
            Save as PDF
          </button>
        </div>

        <p className="mt-4 text-sm text-gray-500">
          By submitting, you agree to our Terms of Service and Privacy Policy
        </p>
      </div>
    </div>
  );
};