// src/pages/policy/PolicyRevealerHooks.tsx
import { useState, useEffect, useCallback } from "react";
import { Policy } from "./PolicyRevealer";

const API_BASE = "/api";
const IN_TOKEN_KEY = "in-token";

async function fetchJson(url: string, init?: RequestInit) {
  const res = await fetch(url, init);
  const text = await res.text().catch(() => "");
  let json: any = null;
  try {
    json = text ? JSON.parse(text) : null;
  } catch {
    json = null;
  }
  return { res, text, json };
}

async function fetchJsonWithFallback(
  primaryUrl: string,
  fallbackUrl: string,
  init?: RequestInit
) {
  const a = await fetchJson(primaryUrl, init);

  if (a.res.ok) return a.json ?? {};

  if (a.res.status === 401 || a.res.status === 403) {
    const err: any = new Error(a.text || `Unauthorized (${a.res.status})`);
    err.status = a.res.status;
    throw err;
  }

  const shouldFallback =
    a.res.status === 404 ||
    (a.res.status >= 500 &&
      (a.text || "").toLowerCase().includes("no static resource"));

  if (!shouldFallback) {
    const err: any = new Error(
      `Failed to load policies (${a.res.status})${a.text ? `: ${a.text}` : ""}`
    );
    err.status = a.res.status;
    throw err;
  }

  const b = await fetchJson(fallbackUrl, init);

  if (b.res.ok) return b.json ?? {};

  const err: any = new Error(
    `Failed to load policies (${b.res.status})${b.text ? `: ${b.text}` : ""}`
  );
  err.status = b.res.status;
  throw err;
}

function extractList(data: any): Policy[] {
  if (Array.isArray(data)) return data as Policy[];

  const candidates = [
    data?.items,
    data?.data,
    data?.results,
    data?.content,
    data?.policies,
  ];
  for (const c of candidates) {
    if (Array.isArray(c)) return c as Policy[];
  }

  const nestedCandidates = [
    data?.data?.items,
    data?.data?.results,
    data?.data?.content,
    data?.payload?.items,
    data?.payload?.results,
  ];
  for (const c of nestedCandidates) {
    if (Array.isArray(c)) return c as Policy[];
  }

  return [];
}

export const usePolicyData = () => {
  const [policies, setPolicies] = useState<Policy[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  const fetchPolicies = useCallback(async () => {
    setLoading(true);
    setError("");

    const token = localStorage.getItem(IN_TOKEN_KEY);

    if (!token) {
      setPolicies([]);
      setError("You must be logged in to view policies.");
      setLoading(false);
      return;
    }

    try {
      const init: RequestInit = {
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
      };

      // ✅ Try exact endpoints first; then trailing slash variants
      let data: any;
      try {
        data = await fetchJsonWithFallback(
          `${API_BASE}/customer/policies`,
          `${API_BASE}/policies`,
          init
        );
      } catch {
        data = await fetchJsonWithFallback(
          `${API_BASE}/customer/policies/`,
          `${API_BASE}/policies/`,
          init
        );
      }

      console.log("🔍 Policies response:", data);

      const list = extractList(data);
      setPolicies(list);
    } catch (err: any) {
      setPolicies([]);
      if (err?.status === 401 || err?.status === 403) {
        setError("Unauthorized (401/403). Please login again.");
      } else {
        setError(err?.message || "Error loading policies");
      }
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchPolicies();
  }, [fetchPolicies]);

  return { policies, loading, error, refetch: fetchPolicies };
};
