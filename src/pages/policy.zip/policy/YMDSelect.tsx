// src/pages/policy/YMDSelect.tsx
import React from "react";
import { Calendar as CalendarIcon, X } from "lucide-react";

/**
 * ✅ Keeps your same output format: ISO "YYYY-MM-DD"
 * ✅ Much faster UX:
 *   - User can type directly (YYYY-MM-DD, YYYY/MM/DD, MM/DD/YYYY)
 *   - Or pick from a native date picker (one click)
 * ✅ Still supports minYear/maxYear + required/disabled + helper/error text
 *
 * NOTE: Native date input is the most user friendly + fastest with zero dependencies.
 */

export const pad2 = (n: number) => String(n).padStart(2, "0");

export const parseISO = (iso?: string) => {
  if (!iso || typeof iso !== "string") return { y: "", m: "", d: "" };
  const parts = iso.split("-");
  if (parts.length !== 3) return { y: "", m: "", d: "" };
  const [y, m, d] = parts;
  const yy = (y || "").trim();
  const mm = (m || "").trim();
  const dd = (d || "").trim();
  if (!yy || !mm || !dd) return { y: yy || "", m: mm || "", d: dd || "" };
  if (!/^\d{4}$/.test(yy)) return { y: "", m: "", d: "" };
  if (!/^\d{1,2}$/.test(mm)) return { y: yy, m: "", d: "" };
  if (!/^\d{1,2}$/.test(dd)) return { y: yy, m: String(Number(mm)), d: "" };
  return { y: yy, m: String(Number(mm)), d: String(Number(dd)) };
};

const isValidYMD = (y: string, m: string, d: string) => {
  if (!y || !m || !d) return false;
  const yn = Number(y);
  const mn = Number(m);
  const dn = Number(d);
  if (!Number.isFinite(yn) || !Number.isFinite(mn) || !Number.isFinite(dn)) return false;
  if (mn < 1 || mn > 12) return false;
  if (dn < 1) return false;
  const md = new Date(yn, mn, 0).getDate();
  return dn <= md;
};

export const toISO = (y: string, m: string, d: string) => {
  if (!isValidYMD(y, m, d)) return "";
  return `${y}-${pad2(Number(m))}-${pad2(Number(d))}`;
};

// Accepts: "YYYY-MM-DD", "YYYY/MM/DD", "MM/DD/YYYY", "MM-DD-YYYY"
const normalizeTypedDateToISO = (raw: string): string => {
  const s = (raw || "").trim();
  if (!s) return "";

  // If it's already ISO-ish, normalize separators.
  const isoLike = s.replace(/\//g, "-");
  const parts = isoLike.split("-").map((p) => p.trim()).filter(Boolean);

  if (parts.length !== 3) return "";

  // Detect format
  // YYYY-MM-DD
  if (/^\d{4}$/.test(parts[0])) {
    const y = parts[0];
    const m = String(Number(parts[1] || ""));
    const d = String(Number(parts[2] || ""));
    return toISO(y, m, d);
  }

  // MM-DD-YYYY
  if (/^\d{4}$/.test(parts[2])) {
    const y = parts[2];
    const m = String(Number(parts[0] || ""));
    const d = String(Number(parts[1] || ""));
    return toISO(y, m, d);
  }

  return "";
};

export type YMDValue = { y: string; m: string; d: string };

interface YMDSelectProps {
  label: string;
  valueISO: string;
  onChangeISO: (nextISO: string) => void;

  minYear?: number;
  maxYear?: number;
  required?: boolean;
  disabled?: boolean;

  helperText?: string;
  errorText?: string;
  name?: string;

  // Keep prop for compatibility; we now show a faster UI but same output
  displayOrder?: ("Y" | "M" | "D")[];
}

export const YMDSelect: React.FC<YMDSelectProps> = ({
  label,
  valueISO,
  onChangeISO,
  minYear = 1950,
  maxYear = new Date().getFullYear() + 10,
  required = false,
  disabled = false,
  helperText,
  errorText,
  name,
}) => {
  const [typed, setTyped] = React.useState<string>(valueISO || "");

  React.useEffect(() => {
    setTyped(valueISO || "");
  }, [valueISO]);

  // Native input constraints (YYYY-MM-DD)
  const minISO = `${minYear}-01-01`;
  const maxISO = `${maxYear}-12-31`;

  const commitISO = (iso: string) => {
    if (disabled) return;
    onChangeISO(iso);
  };

  const base =
    "block w-full rounded-xl border px-3 py-2.5 text-sm shadow-sm focus:outline-none focus:ring-1";
  const enabled =
    "border-slate-300 bg-white text-slate-900 focus:border-slate-900 focus:ring-slate-900";
  const disabledCls =
    "border-slate-200 bg-slate-50 text-slate-500 cursor-not-allowed";
  const invalidCls = errorText
    ? "border-red-400 focus:border-red-600 focus:ring-red-600"
    : "";

  const inputClass = `${base} ${disabled ? disabledCls : enabled} ${invalidCls}`;

  const preview = valueISO || "YYYY-MM-DD";

  return (
    <div>
      <div className="flex items-center justify-between mb-2">
        <label className="block text-sm font-medium text-slate-700">
          {label} {required && <span className="text-red-500">*</span>}
        </label>
        <span className="text-xs text-slate-500">{preview}</span>
      </div>

      {/* Fast entry row: Type OR pick */}
      <div className="grid gap-3 md:grid-cols-2">
        {/* 1) Typing field (very fast) */}
        <div className="relative">
          <input
            value={typed}
            onChange={(e) => {
              const v = e.target.value;
              setTyped(v);

              // only commit when it parses to a valid date
              const iso = normalizeTypedDateToISO(v);
              if (iso) commitISO(iso);
              // allow clearing
              if (!v.trim()) commitISO("");
            }}
            onBlur={() => {
              // On blur, try normalize typed value; if invalid, keep typed (user sees what they typed)
              const iso = normalizeTypedDateToISO(typed);
              if (iso) {
                setTyped(iso);
                commitISO(iso);
              }
            }}
            placeholder="Type: YYYY-MM-DD or MM/DD/YYYY"
            className={inputClass}
            disabled={disabled}
            aria-label={`${label} typed`}
            inputMode="numeric"
            autoComplete="off"
          />

          {/* Clear */}
          {!disabled && typed && (
            <button
              type="button"
              onClick={() => {
                setTyped("");
                commitISO("");
              }}
              className="absolute right-2 top-1/2 -translate-y-1/2 p-1.5 rounded-lg hover:bg-slate-100"
              aria-label="Clear date"
            >
              <X size={16} className="text-slate-500" />
            </button>
          )}
        </div>

        {/* 2) Native date picker */}
        <div className="relative">
          <input
            type="date"
            value={valueISO || ""}
            min={minISO}
            max={maxISO}
            onChange={(e) => {
              const iso = e.target.value || "";
              // native already outputs YYYY-MM-DD
              setTyped(iso);
              commitISO(iso);
            }}
            className={`${inputClass} pr-10`}
            disabled={disabled}
            aria-label={`${label} picker`}
          />
          <CalendarIcon
            size={18}
            className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 pointer-events-none"
          />
        </div>
      </div>

      {/* Help / error */}
      {(helperText || errorText) && (
        <div className="mt-2 text-xs">
          {errorText ? (
            <p className="text-red-600">{errorText}</p>
          ) : (
            <p className="text-slate-500">{helperText ?? "Tip: You can type or pick a date."}</p>
          )}
        </div>
      )}

      {/* Useful for form libs */}
      <input type="hidden" name={name} value={valueISO || ""} />
    </div>
  );
};
