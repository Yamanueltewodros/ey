import { useState, useCallback } from "react";
import { PolicyType, Product, CoverageOption } from "./PolicyAdder";

const API_BASE = "/api";
const IN_TOKEN_KEY = "in-token";

// helper: build headers (adds Authorization only if token exists)
function buildHeaders() {
  const token = localStorage.getItem(IN_TOKEN_KEY);
  return {
    Accept: "application/json",
    "Content-Type": "application/json",
    ...(token ? { Authorization: `Bearer ${token}` } : {}),
  } as Record<string, string>;
}

// helper: normalize API responses (array | {data} | {content})
async function parseList<T>(res: Response): Promise<T[]> {
  const text = await res.text().catch(() => "");
  if (!res.ok) {
    throw new Error(`Request failed (${res.status})${text ? `: ${text}` : ""}`);
  }

  let json: any = null;
  try {
    json = text ? JSON.parse(text) : null;
  } catch {
    json = null;
  }

  if (Array.isArray(json)) return json as T[];
  if (Array.isArray(json?.data)) return json.data as T[];
  if (Array.isArray(json?.content)) return json.content as T[];
  return [];
}

// helper: parse single item response
async function parseItem<T>(res: Response): Promise<T | null> {
  const text = await res.text().catch(() => "");
  if (!res.ok) {
    throw new Error(`Request failed (${res.status})${text ? `: ${text}` : ""}`);
  }

  try {
    return text ? JSON.parse(text) : null;
  } catch {
    return null;
  }
}

/** ───────────────────────── Existing hooks ───────────────────────── */

export const usePolicyTypes = (
  selectedPolicyTypeId: string,
  setSelectedPolicyTypeId: (id: string) => void
) => {
  const [policyTypes, setPolicyTypes] = useState<PolicyType[]>([]);
  const [loadingTypes, setLoadingTypes] = useState(false);
  const [error, setError] = useState("");

  const fetchPolicyTypes = useCallback(async () => {
    setLoadingTypes(true);
    setError("");

    try {
      const res = await fetch(`${API_BASE}/p/types`, {
        headers: buildHeaders(),
      });

      const data = await parseList<PolicyType>(res);

      setPolicyTypes(data || []);
      if ((!selectedPolicyTypeId || selectedPolicyTypeId === "") && data.length > 0) {
        setSelectedPolicyTypeId(data[0].id);
      }
    } catch (err: any) {
      setPolicyTypes([]);
      setError(err?.message || "Error loading policy types");
    } finally {
      setLoadingTypes(false);
    }
  }, [selectedPolicyTypeId, setSelectedPolicyTypeId]);

  return { policyTypes, loadingTypes, error, fetchPolicyTypes };
};

export const useProducts = (
  selectedPolicyTypeId: string,
  setSelectedProductId: (id: string) => void
) => {
  const [products, setProducts] = useState<Product[]>([]);
  const [loadingProducts, setLoadingProducts] = useState(false);
  const [error, setError] = useState("");

  const fetchProducts = useCallback(async () => {
    if (!selectedPolicyTypeId) {
      setProducts([]);
      setSelectedProductId("");
      return;
    }

    setLoadingProducts(true);
    setError("");

    try {
      const res = await fetch(`${API_BASE}/p/products/pt/${selectedPolicyTypeId}`, {
        headers: buildHeaders(),
      });

      const data = await parseList<Product>(res);

      setProducts(data || []);
      if (data.length > 0) setSelectedProductId(data[0].id);
      else setSelectedProductId("");
    } catch (err: any) {
      setProducts([]);
      setSelectedProductId("");
      setError(err?.message || "Error loading products");
    } finally {
      setLoadingProducts(false);
    }
  }, [selectedPolicyTypeId, setSelectedProductId]);

  return { products, loadingProducts, error, fetchProducts };
};

export const useCoverages = (selectedProductId: string) => {
  const [coverageOptions, setCoverageOptions] = useState<CoverageOption[]>([]);
  const [loadingCoverages, setLoadingCoverages] = useState(false);
  const [error, setError] = useState("");

  const fetchCoverages = useCallback(async () => {
    if (!selectedProductId) {
      setCoverageOptions([]);
      return;
    }

    setLoadingCoverages(true);
    setError("");

    try {
      const res = await fetch(`${API_BASE}/p/coverages/i/${selectedProductId}`, {
        headers: buildHeaders(),
      });

      const data = await parseList<CoverageOption>(res);

      setCoverageOptions(data || []);
    } catch (err: any) {
      setCoverageOptions([]);
      setError(err?.message || "Error loading coverage options");
    } finally {
      setLoadingCoverages(false);
    }
  }, [selectedProductId]);

  return { coverageOptions, loadingCoverages, error, fetchCoverages };
};

/** ───────────────────────── Asset hooks ───────────────────────── */

export type AssetType = {
  id: string; // UUID
  name?: string;
  description?: string;
  [key: string]: any;
};

export type AssetServiceDto = {
  id: string;
  code?: string;
  name?: string;
  description?: string;
  [key: string]: any;
};

export type AssetUsageDto = {
  id: string;
  code?: string;
  name?: string;
  description?: string;
  services?: AssetServiceDto[];
  [key: string]: any;
};

export type AssetActivityDto = {
  id: string;
  code?: string;
  name?: string;
  description?: string;
  usages?: AssetUsageDto[];
  [key: string]: any;
};

// Helper function to create readable names from codes
const formatDisplayName = (code?: string, fallback?: string): string => {
  if (code) {
    // Convert "PASSENGER_FOR_HIRE" to "Passenger For Hire"
    return code.replace(/_/g, ' ').toLowerCase()
      .replace(/\b\w/g, l => l.toUpperCase());
  }
  return fallback || 'Unknown';
};

// 1. GET all AssetTypes
export const useAssetTypes = (selectedAssetTypeId: string, setSelectedAssetTypeId: (id: string) => void) => {
  const [assetTypes, setAssetTypes] = useState<AssetType[]>([]);
  const [loadingAssetTypes, setLoadingAssetTypes] = useState(false);
  const [error, setError] = useState("");

  const fetchAssetTypes = useCallback(async () => {
    setLoadingAssetTypes(true);
    setError("");

    try {
      const res = await fetch(`${API_BASE}/asset/types`, {
        headers: buildHeaders(),
      });

      const data = await parseList<AssetType>(res);

      setAssetTypes(data || []);
      if ((!selectedAssetTypeId || selectedAssetTypeId === "") && data.length > 0) {
        setSelectedAssetTypeId(data[0].id);
      }
    } catch (err: any) {
      setAssetTypes([]);
      setError(err?.message || "Error loading asset types");
    } finally {
      setLoadingAssetTypes(false);
    }
  }, [selectedAssetTypeId, setSelectedAssetTypeId]);

  return { assetTypes, loadingAssetTypes, error, fetchAssetTypes };
};

// 2. GET all AssetActivities by AssetType - FIXED
export const useAssetActivities = (assetTypeId: string) => {
  const [activities, setActivities] = useState<AssetActivityDto[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  const fetchActivities = useCallback(async () => {
    if (!assetTypeId) {
      setActivities([]);
      return;
    }

    setLoading(true);
    setError("");

    try {
      const res = await fetch(`${API_BASE}/asset/activities/${assetTypeId}`, {
        headers: buildHeaders(),
      });

      const data = await parseList<AssetActivityDto>(res);
      
      // Transform activities using the CODE field
      const transformedActivities = data.map(activity => {
        const displayName = formatDisplayName(activity.code, activity.name);
        
        // Transform usages using their CODE fields
        const transformedUsages = activity.usages?.map(usage => {
          const usageName = formatDisplayName(usage.code, usage.name);
          
          // Transform services using their CODE fields
          const transformedServices = usage.services?.map(service => {
            const serviceName = formatDisplayName(service.code, service.name);
            return { ...service, name: serviceName };
          }) || [];
          
          return { ...usage, name: usageName, services: transformedServices };
        }) || [];
        
        return { 
          ...activity, 
          name: displayName,
          usages: transformedUsages 
        };
      });
      
      setActivities(transformedActivities || []);
    } catch (err: any) {
      setActivities([]);
      setError(err?.message || "Error loading asset activities");
    } finally {
      setLoading(false);
    }
  }, [assetTypeId]);

  return { activities, loading, error, fetchActivities };
};

// 3. GET Activity Usages - FIXED
export const useActivityUsages = (activityId: string) => {
  const [usages, setUsages] = useState<AssetUsageDto[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  const fetchUsages = useCallback(async () => {
    if (!activityId) {
      setUsages([]);
      return;
    }

    setLoading(true);
    setError("");

    try {
      const res = await fetch(`${API_BASE}/asset/usages/${activityId}`, {
        headers: buildHeaders(),
      });

      const data = await parseList<AssetUsageDto>(res);
      
      // Use the CODE field for display names
      const transformedUsages = data.map(usage => {
        const displayName = formatDisplayName(usage.code, usage.name);
        
        // Transform services using CODE field
        const transformedServices = usage.services?.map(service => {
          const serviceName = formatDisplayName(service.code, service.name);
          return { ...service, name: serviceName };
        }) || [];
        
        return { ...usage, name: displayName, services: transformedServices };
      });
      
      setUsages(transformedUsages || []);
    } catch (err: any) {
      setUsages([]);
      setError(err?.message || "Error loading activity usages");
    } finally {
      setLoading(false);
    }
  }, [activityId]);

  return { usages, loading, error, fetchUsages };
};

// 4. GET Usage Services - FIXED
export const useUsageServices = (usageId: string) => {
  const [services, setServices] = useState<AssetServiceDto[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  const fetchServices = useCallback(async () => {
    if (!usageId) {
      setServices([]);
      return;
    }

    setLoading(true);
    setError("");

    try {
      const res = await fetch(`${API_BASE}/asset/services/${usageId}`, {
        headers: buildHeaders(),
      });

      const data = await parseList<AssetServiceDto>(res);
      
      // Use the CODE field for display names
      const transformedServices = data.map(service => {
        const displayName = formatDisplayName(service.code, service.name);
        return { ...service, name: displayName };
      });
      
      setServices(transformedServices || []);
    } catch (err: any) {
      setServices([]);
      setError(err?.message || "Error loading usage services");
    } finally {
      setLoading(false);
    }
  }, [usageId]);

  return { services, loading, error, fetchServices };
};

/** ───────────────────────── Vehicle specific hooks ───────────────────────── */

export type VehicleMake = {
  make?: string;
  id?: string;
  name?: string;
  [key: string]: any;
};

export type VehicleModel = {
  model?: string;
  make?: string;
  id?: string;
  name?: string;
  [key: string]: any;
};

export type VehicleCategory = {
  category?: string;
  model?: string;
  make?: string;
  id?: string;
  name?: string;
  [key: string]: any;
};

export type VehicleYear = {
  year?: number;
  category?: string;
  model?: string;
  make?: string;
  id?: string;
  name?: string;
  [key: string]: any;
};

// 5. GET all Vehicles (makes)
export const useVehicleMakes = () => {
  const [makes, setMakes] = useState<VehicleMake[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  const fetchMakes = useCallback(async () => {
    setLoading(true);
    setError("");

    try {
      const res = await fetch(`${API_BASE}/vehicles/makes`, {
        headers: buildHeaders(),
      });

      const data = await parseList<VehicleMake>(res);
      
      const transformedMakes = data.map(make => ({
        ...make,
        name: make.name || make.make || make.id || 'Unknown Make'
      }));
      
      setMakes(transformedMakes || []);
    } catch (err: any) {
      setMakes([]);
      setError(err?.message || "Error loading vehicle makes");
    } finally {
      setLoading(false);
    }
  }, []);

  return { makes, loading, error, fetchMakes };
};

// 6. GET all Models for a given Make
export const useVehicleModels = (make: string) => {
  const [models, setModels] = useState<VehicleModel[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  const fetchModels = useCallback(async () => {
    if (!make) {
      setModels([]);
      return;
    }

    setLoading(true);
    setError("");

    try {
      const res = await fetch(`${API_BASE}/vehicles/make/${make}`, {
        headers: buildHeaders(),
      });

      const data = await parseList<VehicleModel>(res);
      
      // Ensure models have readable names
      const transformedModels = data.map(model => ({
        ...model,
        name: model.name || model.model || model.id || 'Unknown Model'
      }));
      
      setModels(transformedModels || []);
    } catch (err: any) {
      setModels([]);
      setError(err?.message || "Error loading vehicle models");
    } finally {
      setLoading(false);
    }
  }, [make]);

  return { models, loading, error, fetchModels };
};

// 7. GET all categories for a given Model
export const useVehicleCategories = (make: string, model: string) => {
  const [categories, setCategories] = useState<VehicleCategory[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  const fetchCategories = useCallback(async () => {
    if (!make || !model) {
      setCategories([]);
      return;
    }

    setLoading(true);
    setError("");

    try {
      const res = await fetch(`${API_BASE}/vehicles/make/${make}/model/${model}`, {
        headers: buildHeaders(),
      });

      const data = await parseList<VehicleCategory>(res);
      
      // Ensure categories have readable names
      const transformedCategories = data.map(category => ({
        ...category,
        name: category.name || category.category || category.id || 'Unknown Category'
      }));
      
      setCategories(transformedCategories || []);
    } catch (err: any) {
      setCategories([]);
      setError(err?.message || "Error loading vehicle categories");
    } finally {
      setLoading(false);
    }
  }, [make, model]);

  return { categories, loading, error, fetchCategories };
};

// 8. GET all years for a given Make and Model (UPDATED - uses /year endpoint)
export const useVehicleYears = (make: string, model: string) => {
  const [years, setYears] = useState<VehicleYear[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  const fetchYears = useCallback(async () => {
    console.log('🔍 useVehicleYears called with:', { make, model });
    
    if (!make || !model) {
      console.log('❌ Missing make or model for years fetch');
      setYears([]);
      return;
    }

    setLoading(true);
    setError("");

    try {
      // URL encode parameters to handle spaces/special characters
      const encodedMake = encodeURIComponent(make);
      const encodedModel = encodeURIComponent(model);
      
      // Use the exact endpoint format: /api/vehicles/make/{make}/model/{model}/year
      const url = `${API_BASE}/vehicles/make/${encodedMake}/model/${encodedModel}/year`;
      console.log('🌐 Fetching years from:', url);
      
      const res = await fetch(url, {
        headers: buildHeaders(),
      });

      console.log('📊 Years API response status:', res.status);
      
      if (!res.ok) {
        throw new Error(`Failed to fetch years (${res.status}): ${res.statusText}`);
      }

      const data = await parseList<VehicleYear>(res);
      
      console.log('✅ Years data received:', data);
      
      // Ensure years have readable names
      const transformedYears = data.map(yearItem => ({
        ...yearItem,
        name: yearItem.name || (yearItem.year ? yearItem.year.toString() : yearItem.id || 'Unknown Year')
      }));
      
      setYears(transformedYears || []);
    } catch (err: any) {
      console.error('❌ Error fetching years:', err);
      setYears([]);
      setError(err?.message || "Error loading vehicle years");
    } finally {
      setLoading(false);
    }
  }, [make, model]);

  return { years, loading, error, fetchYears };
};